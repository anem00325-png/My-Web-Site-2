import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';

interface BusinessGuideResult {
    text: string;
    imageUrl: string | null;
}

interface BusinessAssistantPageProps {
    onGenerate: (description: string, image: { data: string, mimeType: string } | null) => void;
    isLoading: boolean;
    result: BusinessGuideResult | null;
}

const BusinessAssistantPage: React.FC<BusinessAssistantPageProps> = ({ onGenerate, isLoading, result }) => {
    const { t } = useLanguage();
    const { showToast } = useToast();
    const [description, setDescription] = useState('');
    const [image, setImage] = useState<{ file: File, preview: string } | null>(null);

    const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const MAX_SIZE_MB = 2;
            if (file.size > MAX_SIZE_MB * 1024 * 1024) {
                showToast(t('toast.imageTooLarge', { size: MAX_SIZE_MB }), 'error');
                return;
            }
            const preview = URL.createObjectURL(file);
            setImage({ file, preview });
        }
    };
    
    const handleRemoveImage = () => {
        if(image) {
            URL.revokeObjectURL(image.preview);
        }
        setImage(null);
    };

    const fileToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve((reader.result as string).split(',')[1]);
            reader.onerror = error => reject(error);
        });
    };

    const handleSubmit = async () => {
        if (!description.trim()) {
            showToast(t('toast.descriptionMissing'), 'error');
            return;
        }

        let imageData: { data: string, mimeType: string } | null = null;
        if (image) {
            const base64Data = await fileToBase64(image.file);
            imageData = { data: base64Data, mimeType: image.file.type };
        }

        onGenerate(description, imageData);
    };
    
    const renderResult = () => {
        if (!result) return null;
        
        const contentBlocks = result.text.split(/(\n##\s.*?\n)/).filter(Boolean);

        return (
            <div>
                 {result.imageUrl && (
                    <img src={result.imageUrl} alt="AI Generated Concept" className="rounded-lg mb-6 w-full max-w-md mx-auto shadow-lg border-4 border-dark-700" />
                 )}
                 <div className="space-y-6">
                    {contentBlocks.map((block, index) => {
                        if (block.startsWith('\n## ')) {
                            return <h2 key={index} className="text-2xl font-bold text-white border-b-2 border-primary/50 pb-2">{block.replace('\n## ','').trim()}</h2>
                        }
                        return (
                            <div key={index} className="text-dark-300 space-y-2">
                                {block.split('\n').map((line, lineIndex) => {
                                    if (line.startsWith('### ')) return <h3 key={lineIndex} className="text-xl font-semibold text-primary/90 mt-4">{line.substring(4)}</h3>;
                                    if (line.startsWith('- ')) return <li key={lineIndex} className="list-disc list-inside ml-4">{line.substring(2)}</li>;
                                    if (line.trim()) return <p key={lineIndex}>{line}</p>;
                                    return null;
                                })}
                            </div>
                        )
                    })}
                 </div>
            </div>
        );
    };

    return (
        <div className="space-y-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-extrabold text-white sm:text-4xl">{t('businessGuide.title')}</h2>
                <p className="mt-3 max-w-2xl mx-auto text-lg text-dark-400">{t('businessGuide.subtitle')}</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Input Section */}
                <div className="bg-dark-800 p-6 rounded-lg shadow-lg space-y-6">
                    <div>
                        <label htmlFor="businessDescription" className="block text-lg font-medium text-dark-200 mb-2">{t('businessGuide.businessDescriptionLabel')}</label>
                        <textarea
                            id="businessDescription"
                            rows={10}
                            className="w-full bg-dark-700 border border-dark-600 rounded-md px-4 py-3 text-white placeholder-dark-500 focus:ring-2 focus:ring-primary focus:border-primary transition"
                            placeholder={t('businessGuide.businessDescriptionPlaceholder')}
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                        />
                    </div>
                    <div>
                        <label className="block text-lg font-medium text-dark-200 mb-2">{t('businessGuide.uploadImageLabel')}</label>
                        {image ? (
                            <div className="relative w-full h-48 group">
                                <img src={image.preview} alt="Product Preview" className="w-full h-full object-cover rounded-md" />
                                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                    <button onClick={handleRemoveImage} className="bg-danger text-white font-bold py-2 px-4 rounded-md">{t('businessGuide.removeImage')}</button>
                                </div>
                            </div>
                        ) : (
                            <label htmlFor="imageUpload" className="relative flex flex-col items-center justify-center w-full h-48 border-2 border-dark-600 border-dashed rounded-lg cursor-pointer bg-dark-700/50 hover:bg-dark-700/80 transition">
                                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                    <svg className="w-10 h-10 mb-3 text-dark-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg>
                                    <p className="mb-2 text-sm text-dark-400"><span className="font-semibold">{t('businessGuide.uploadImageButton')}</span></p>
                                    <p className="text-xs text-dark-500">PNG, JPG, WEBP (MAX. 2MB)</p>
                                </div>
                                <input id="imageUpload" type="file" className="hidden" accept="image/png, image/jpeg, image/webp" onChange={handleImageChange} />
                            </label>
                        )}
                    </div>
                     <button
                        onClick={handleSubmit}
                        disabled={isLoading || !description.trim()}
                        className="w-full bg-primary hover:bg-blue-600 text-white font-bold py-3 px-4 rounded-lg transition duration-300 transform hover:scale-105 disabled:bg-dark-600 disabled:cursor-not-allowed disabled:scale-100"
                      >
                        {isLoading ? t('businessGuide.loading') : t('businessGuide.generateButton')}
                      </button>
                </div>

                {/* Output Section */}
                <div className="bg-dark-800 p-6 rounded-lg shadow-lg">
                     <h3 className="text-xl font-bold mb-4 text-center">{t('businessGuide.resultsTitle')}</h3>
                     <div className="min-h-[400px] max-h-[60vh] overflow-y-auto p-4 bg-dark-900/50 rounded-md">
                        {isLoading ? (
                            <div className="flex flex-col items-center justify-center h-full">
                                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                                <p className="mt-4 text-dark-300">{t('businessGuide.loading')}</p>
                            </div>
                        ) : result ? (
                            renderResult()
                        ) : (
                             <div className="flex flex-col items-center justify-center h-full text-center text-dark-500">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.375 3.375 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                                <p>{t('businessGuide.initialState')}</p>
                            </div>
                        )}
                     </div>
                </div>
            </div>
             <style>{`
                @keyframes fade-in {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default BusinessAssistantPage;
