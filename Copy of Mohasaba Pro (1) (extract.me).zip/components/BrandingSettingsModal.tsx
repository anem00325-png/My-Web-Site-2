// This file was renamed to InvoiceSettingsModal.tsx
// The content is now in the new file.
